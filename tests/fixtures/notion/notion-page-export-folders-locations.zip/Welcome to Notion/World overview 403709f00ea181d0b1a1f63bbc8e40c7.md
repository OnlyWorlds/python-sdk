# World overview

## The shore

A small world of one coast: a harbour city, a hill town, an inn, a lake and the road between them.

Every character has a home here, except one on purpose.

## How to read this world

- Places hold the map.
- Characters hold the people.

[Calendar and seasons](World%20overview/Calendar%20and%20seasons%20403709f00ea181c09f8ec0ae0e740fe4.md)