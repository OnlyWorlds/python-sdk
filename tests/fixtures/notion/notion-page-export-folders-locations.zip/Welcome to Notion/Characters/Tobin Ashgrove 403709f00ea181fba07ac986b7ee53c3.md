# Tobin Ashgrove

Born: July 2, 1389
Location: Stonewick (../Locations/Stonewick%20403709f00ea1819fa981cb94db1d326c.md)
Notes: Keeps the Stonewick bees. Distrusts roads.
Species: Halfling