# Calendar and seasons

Twelve months of thirty days and a free week at midwinter.

The Long Frost is year 1427 in the harbour's reckoning.