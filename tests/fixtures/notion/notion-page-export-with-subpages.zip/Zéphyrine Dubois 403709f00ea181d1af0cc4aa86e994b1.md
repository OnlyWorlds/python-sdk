# Zéphyrine Dubois

Born: November 30, 987
Home: Lac Élan (Lac%20%C3%89lan%20403709f00ea181c2b575c71a2bdfa244.md)
Notes: Maps the lake's moods; has not been wrong about weather in a century.
Species: Elf